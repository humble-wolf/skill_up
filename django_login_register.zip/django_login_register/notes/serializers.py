from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Note, AudioNote


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password', 'email']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user
    
class AudioNoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = AudioNote
        fields = ['id', 'note', 'audio_file']

class NoteSerializer(serializers.ModelSerializer):
    audio_notes = AudioNoteSerializer(many=True, read_only=True)
    class Meta:
        model = Note
        fields = ['id', 'title', 'description', 'user', 'audio_notes']
        read_only_fields = ['user']