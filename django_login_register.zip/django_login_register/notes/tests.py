from django.contrib.auth.models import User
from rest_framework.test import APITestCase
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from .models import Note, AudioNote

class AuthTests(APITestCase):
    def setUp(self):
        # Create a test user
        self.user_data = {
            'username': 'testuser',
            'email': 'test@email.com',
            'password': 'a',
        }
        self.user = User.objects.create_user(**self.user_data)
        self.url_register = '/api/register/'
        self.url_login = '/api/login/'

    def test_register(self):
        data = {
            'username': 'newuser',
            'email': 'newuser@email.com',
            'password': 'a',
        }
        response = self.client.post(self.url_register, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_login(self):
        data = {
            'email': self.user_data['email'],
            'password': self.user_data['password'],
        }
        response = self.client.post(self.url_login, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access_token', response.data)
        self.assertIn('refresh_token', response.data)

    def test_login_invalid(self):
        data = {
            'email': 'wrong_test@email.com',
            'password': 'a',
        }
        response = self.client.post(self.url_login, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['error'], 'Invalid credentials')


class NoteTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(email="test@email.com", username="test_user", password="a")
        refresh = RefreshToken.for_user(self.user)
        self.access_token = str(refresh.access_token)
        self.note_data = {"title": "Test note", "description": "This is a test note."}
        self.url_notes = '/api/notes/'

    def test_create_note_authenticated(self):
        response = self.client.post(
            self.url_notes,
            self.note_data,
            HTTP_AUTHORIZATION=f'Bearer {self.access_token}',
            format='json'
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['title'], self.note_data['title'])

    def test_get_notes_authenticated(self):
        Note.objects.create(title="Existing note", description="Existing note desc", user=self.user)
        response = self.client.get(
            self.url_notes,
            HTTP_AUTHORIZATION=f'Bearer {self.access_token}'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)

    def test_update_note_authenticated(self):
        note = Note.objects.create(title="Old title", description="Old description", user=self.user)
        updated_data = {"title": "New title", "description": "New descriptiom"}
        response = self.client.put(
            f'/api/notes/{note.id}/',
            updated_data,
            HTTP_AUTHORIZATION=f'Bearer {self.access_token}',
            format='json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['title'], updated_data['title'])

    def test_delete_note_authenticated(self):
        note = Note.objects.create(title="Delete title", description="Delete me", user=self.user)
        response = self.client.delete(
            f'/api/notes/{note.id}/',
            HTTP_AUTHORIZATION=f'Bearer {self.access_token}'
        )
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertEqual(Note.objects.count(), 0)


from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile

def get_mock_file():
    file = BytesIO(b"fake audio file content")
    file.name = 'test_audio.mp3'
    return InMemoryUploadedFile(file, None, 'test_audio.mp3', 'audio/mpeg', len(file.getvalue()), None)

class AudioNoteTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="testuser", password="password")
        refresh = RefreshToken.for_user(self.user)
        self.access_token = str(refresh.access_token)
        self.note = Note.objects.create(title="Note with Audio", description="Test note for audio", user=self.user)

    def test_create_audio_note_authenticated(self):
        audio_file = get_mock_file()
        response = self.client.post(
            '/api/audio-notes/',
            {
                'note': self.note.id,
                'audio_file': audio_file,
            },
            HTTP_AUTHORIZATION=f'Bearer {self.access_token}',
            format='multipart'
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['note'], self.note.id)

    def test_get_audio_notes_authenticated(self):
        audio_note = AudioNote.objects.create(note=self.note, audio_file="test_audio.mp3")
        response = self.client.get(
            '/api/audio-notes/',
            HTTP_AUTHORIZATION=f'Bearer {self.access_token}'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
